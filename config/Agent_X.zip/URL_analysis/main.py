# main.py
from url_analysis import app

def run_server():
    """启动Flask服务（可配置host和port）"""
    app.run(
        host="0.0.0.0",  # 允许所有IP访问（生产环境建议修改为127.0.0.1）
        port=8080,       # 服务端口（根据需求调整）
        threaded=True    # 开启多线程（处理并发请求）
    )

if __name__ == "__main__":
    run_server()