from mysql_mcp import mcp
if __name__ == "__main__":
    mcp.run(
        transport='sse',  # 调试模式
    )