import uvicorn
from auto_mcp_api import app
import subprocess
import yaml
import os

if __name__ == '__main__':
    def load_config() -> dict:
        """加载并返回配置文件内容"""
        config_path = os.path.join(os.path.dirname(__file__), "config.yml")
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"配置文件未找到：{config_path}")
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    # 全局配置对象（程序启动时加载）
    CONFIG = load_config()
    TARGET_DIR = CONFIG['directory']
    # 调用 shell 脚本并传入参数
    subprocess.run(["/bin/bash", "restart_mcp_services.sh", TARGET_DIR], check=True)
    uvicorn.run(app, host="0.0.0.0", port=10757)