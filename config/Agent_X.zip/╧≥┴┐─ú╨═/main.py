import uvicorn
from embedding_sdk import *
import sys
import logging

logger = logging.getLogger(__name__)

if __name__ == '__main__':
    try:
        config = load_config()
        app = create_app(config)
        server_config = config.get("server", {})
        uvicorn.run(
            app,
            host=server_config.get("host", "0.0.0.0"),
            port=config["models"][config["active_model"]]["port"],
            workers=server_config.get("workers", 1 if config.get("use_gpu", False) else 2)
        )
    except Exception as e:
        logger.error(f"服务启动失败: {str(e)}")
        sys.exit(1)