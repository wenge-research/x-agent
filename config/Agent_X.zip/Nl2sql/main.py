from nl2sql_executor import app

if __name__ == '__main__':
    # 启动Flask服务
    app.run(host='0.0.0.0', port=8080, threaded=True)