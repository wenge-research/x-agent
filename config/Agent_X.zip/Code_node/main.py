from code_executor import create_app

# 创建FastAPI应用
app = create_app()

if __name__ == "__main__":
    import uvicorn
    # 启动服务（默认监听0.0.0.0:8080）
    uvicorn.run(app, host="0.0.0.0", port=8080)